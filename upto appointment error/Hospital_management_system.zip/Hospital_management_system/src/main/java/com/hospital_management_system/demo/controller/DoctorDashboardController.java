package com.hospital_management_system.demo.controller;

import com.hospital_management_system.demo.entity.Doctor;
import com.hospital_management_system.demo.entity.User;
import com.hospital_management_system.demo.service.DoctorService;
import com.hospital_management_system.demo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class DoctorDashboardController {

    @Autowired
    private UserService userService;

    @Autowired
    private DoctorService doctorService;

    @GetMapping("/doctor/dashboard")
    public String doctorDashboard(Authentication authentication, Model model) {
        String username = authentication.getName();
        User user = userService.findByUsername(username);
        if (user == null) {
            return "redirect:/login?error";
        }
        Doctor doctor = doctorService.findByUserid(user.getUserid());
        model.addAttribute("doctor", doctor);
        return "doctor-dashboard";
    }

    @GetMapping("/doctor/profile")
    public String doctorProfile(Authentication authentication, Model model) {
        String username = authentication.getName();
        User user = userService.findByUsername(username);
        if (user == null) {
            return "redirect:/login?error";
        }
        Doctor doctor = doctorService.findByUserid(user.getUserid());
        model.addAttribute("doctor", doctor);
        return "doctor-profile";
    }

    @GetMapping("/doctor/profile/edit")
    public String editOwnProfile(Authentication authentication, Model model) {
        String username = authentication.getName();
        User user = userService.findByUsername(username);
        if (user == null) {
            return "redirect:/login?error";
        }
        Doctor doctor = doctorService.findByUserid(user.getUserid());
        model.addAttribute("doctor", doctor);
        return "edit-doctor";
    }

    @PostMapping("/doctor/profile/edit")
    public String updateOwnProfile(@ModelAttribute Doctor doctor, Authentication authentication) {
        String username = authentication.getName();
        User user = userService.findByUsername(username);
        if (user == null) {
            return "redirect:/login?error";
        }
        doctor.setUserid(user.getUserid());
        doctorService.updateDoctor(doctor);
        return "redirect:/doctor/profile";
    }
}
