package com.hospital_management_system.demo.controller;

import com.hospital_management_system.demo.entity.Appointment;
import com.hospital_management_system.demo.entity.Doctor;
import com.hospital_management_system.demo.entity.Patient;
import com.hospital_management_system.demo.entity.User;
import com.hospital_management_system.demo.service.AppointmentService;
import com.hospital_management_system.demo.service.DoctorService;
import com.hospital_management_system.demo.service.PatientService;
import com.hospital_management_system.demo.service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@Controller
@RequestMapping("/patient/appointments")
public class AppointmentController {

    @Autowired
    private AppointmentService appointmentService;

    @Autowired
    private PatientService patientService;

    @Autowired
    private UserService userService;

    @Autowired
    private DoctorService doctorService;
    
    // View appointment page
    @GetMapping
    public String viewAppointment(Authentication auth, Model model) {
        String username = auth.getName();
        User user = userService.findByUsername(username);
        Patient patient = patientService.findByUserid(user.getUserid());

        Optional<Appointment> appointment = appointmentService.getAppointmentByPatientId(patient.getPatientid());

        model.addAttribute("appointment", appointment.orElse(null));
        model.addAttribute("patientId", patient.getPatientid());
        return "patient-appointment";
    }

    // Show schedule form
    @GetMapping("/schedule")
    public String showScheduleForm(@RequestParam int patientId, Model model) {
    	Appointment appointment = new Appointment();
        appointment.setDoctor(new Doctor());
        model.addAttribute("appointment", new Appointment());
        model.addAttribute("patientId", patientId);
        model.addAttribute("doctors", doctorService.getAllDoctors());
        return "schedule-appointment";
    }

    // Submit new appointment
    @PostMapping("/schedule")
    public String scheduleAppointment(@ModelAttribute Appointment appointment, @RequestParam int patientId) {
        Optional<Appointment> existing = appointmentService.getAppointmentByPatientId(patientId);
        if (existing.isPresent()) {
            return "redirect:/patient/appointments?error=alreadyScheduled";
        }

        Patient patient = patientService.findByUserid(patientId);
//            .orElseThrow(() -> new RuntimeException("Patient not found"));

        appointment.setPatient(patient);
        appointment.setStatus(Appointment.Status.CONFIRMED);
        appointmentService.scheduleAppointment(appointment);
        return "redirect:/patient/appointments";
    }


    // Cancel appointment
    @PostMapping("/cancel")
    public String cancelAppointment(@RequestParam int appointmentId) {
        appointmentService.cancelAppointment(appointmentId);
        return "redirect:/patient/appointments";
    }
}
