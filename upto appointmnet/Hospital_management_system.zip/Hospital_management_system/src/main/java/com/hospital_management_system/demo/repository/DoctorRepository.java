package com.hospital_management_system.demo.repository;

import com.hospital_management_system.demo.entity.Doctor;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface DoctorRepository extends JpaRepository<Doctor, Integer> {
//    Doctor findByUserid(int userid);
	List<Doctor> findByUserid(int userid);
}
