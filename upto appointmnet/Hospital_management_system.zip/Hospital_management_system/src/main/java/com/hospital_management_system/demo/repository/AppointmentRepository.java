package com.hospital_management_system.demo.repository;

import com.hospital_management_system.demo.entity.Appointment;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
public interface AppointmentRepository extends JpaRepository<Appointment, Integer> {
//    Optional<Appointment> findByPatientId(int patientId);
	Optional<Appointment> findByPatient_Patientid(int patientid); // ✅ Correct traversal

}
