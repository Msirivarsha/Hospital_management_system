package com.hospital_management_system.demo.service;

import com.hospital_management_system.demo.entity.Doctor;
import com.hospital_management_system.demo.repository.DoctorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DoctorService {

    @Autowired
    private DoctorRepository doctorRepository;

    public Optional<Doctor> getDoctorDetails(int id) {
        return doctorRepository.findById(id);
    }

    public void deleteDoctor(int id) {
        doctorRepository.deleteById(id);
    }

    public Doctor registerDoctor(Doctor doctor) {
        try {
            Doctor savedDoctor = doctorRepository.save(doctor);
            System.out.println("Doctor saved: " + savedDoctor.getDoctorid());
            return savedDoctor;
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    public Doctor findByUserid(int userid) {
        return doctorRepository.findByUserid(userid);
    }

    public Doctor updateDoctor(Doctor doctor) {
        return doctorRepository.save(doctor);
    }

    public List<Doctor> getAllDoctors() {
        return doctorRepository.findAll();
    }
}
