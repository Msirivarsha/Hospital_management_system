package com.hospital_management_system.demo.service;

import com.hospital_management_system.demo.entity.Appointment;
import com.hospital_management_system.demo.repository.AppointmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AppointmentService {

    @Autowired
    private AppointmentRepository appointmentRepository;

    public Optional<Appointment> getAppointmentByPatientId(int patientId) {
        return appointmentRepository.findByPatient_Patientid(patientId);
    }

    public Appointment scheduleAppointment(Appointment appointment) {
        return appointmentRepository.save(appointment);
    }

    public void cancelAppointment(int appointmentId) {
        appointmentRepository.deleteById(appointmentId);
    }
    public List<Appointment> getAppointmentsByDoctorId(int doctorId) {
        return appointmentRepository.findByDoctor_Doctorid(doctorId);
    }

}
